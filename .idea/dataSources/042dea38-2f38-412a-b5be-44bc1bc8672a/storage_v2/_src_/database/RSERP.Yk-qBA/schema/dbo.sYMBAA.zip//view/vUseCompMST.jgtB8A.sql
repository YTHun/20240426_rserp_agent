
CREATE      VIEW [dbo].[vUseCompMST]
AS
SELECT COMP_GB
      ,COMP_CODE
      ,SUBCOMP_IDNO
      ,CompType
      ,SangHo
      ,RepName
      ,Officetel
      ,OfficeFax
      ,PostalCode
      ,Address
      ,Wdate
      ,Udate
      ,UseYN
      ,SmsYN
      ,SmsKind
      ,SmsInAmt
      ,SmsOutAmt
      ,Mobile11
      ,Mobile12
      ,Mobile13
      ,useMobile1
      ,Mobile21
      ,Mobile22
      ,Mobile23
      ,useMobile2
      ,Mobile31
      ,Mobile32
      ,Mobile33
      ,useMobile3
      ,Mobile41
      ,Mobile42
      ,Mobile43
      ,useMobile4
      ,Mobile51
      ,Mobile52
      ,Mobile53
      ,useMobile5
      ,AptSrpYN
FROM RX2.DB_ACCT.dbo.UseCompMST 

go

