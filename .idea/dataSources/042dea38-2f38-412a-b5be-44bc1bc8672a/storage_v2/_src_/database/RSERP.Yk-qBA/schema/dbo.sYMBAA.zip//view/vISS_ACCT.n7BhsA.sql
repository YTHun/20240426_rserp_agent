

CREATE      VIEW [dbo].[vISS_ACCT]
AS
SELECT COMP_GB
      ,COMP_CODE
      ,BANK_CD
      ,ACCT_NO
      ,IB_TYPE
      ,SUBCOMP_IDNO
      ,DEPOSITOR
      ,ACCT_NICKNAME
      ,ACCT_PW
      ,ACCT_FASTID
      ,ACCT_FASTPW
      ,ACCT_KIND
      ,CLIENT_GB
      ,STATUS
      ,TSTATUS
      ,WDATE
      ,UDATE
      ,TDATE
FROM RX2.DB_ACCT.dbo.ISS_ACCT 


go

